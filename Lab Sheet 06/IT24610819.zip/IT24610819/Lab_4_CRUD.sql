CREATE TABLE Module(
	Mcode varchar(10) PRIMARY KEY, 
	Mname varchar(50),             
	M_description varchar(100),    
	NoOfCredits int
);

CREATE TABLE Course(
	CID varchar(10) PRIMARY KEY,   
	Cname varchar(50),             
	C_description varchar(100),    
	C_fee real
);

CREATE TABLE Student(
	SID varchar(10) PRIMARY KEY,   
	Sname varchar(50),             
	Address varchar(100),          
	dob DATE,
	NIC char(10),
	CID varchar(10),               
	FOREIGN KEY (CID) REFERENCES Course(CID)
);

CREATE TABLE Offers(	
	Academic_year varchar(2),
	Semester int,
	CID varchar(10),               
	Mcode varchar(10),             
	FOREIGN KEY (CID) REFERENCES Course(CID),
	FOREIGN KEY (Mcode) REFERENCES Module(Mcode),
	PRIMARY KEY (CID, Mcode)
);

ALTER TABLE Student
ADD CONSTRAINT chk_Student_NIC
CHECK (NIC LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][Vv]');

ALTER TABLE Module
ADD CONSTRAINT chk_Module_NoOfCredits
CHECK (NoOfCredits IN (1,2,3,4));

SELECT * FROM Course

SELECT * FROM Student

SELECT * FROM Module

SELECT * FROM Offers