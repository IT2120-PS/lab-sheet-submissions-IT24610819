import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    // --- IMPORTANT: UPDATE THESE VALUES WITH YOUR DATABASE DETAILS ---
    private static final String DATABASE_URL = "jdbc:sqlserver://localhost:1433;databaseName=StudentInformation;encrypt=false;";
    private static final String USER = "sa";
    private static final String PASSWORD = "123";

    public static Connection getConnection() {
        try {
            // Attempt to connect to the database
            Connection connection = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
            System.out.println("✅ Connection to SQL Server successful!");
            return connection;
        } catch (SQLException e) {
            // Print an error message if the connection fails
            System.err.println("❌ Database connection failed!");
            e.printStackTrace();
            return null;
        }
    }
}