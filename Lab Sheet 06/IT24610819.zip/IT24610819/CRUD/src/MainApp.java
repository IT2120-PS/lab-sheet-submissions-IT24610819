import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("main-view.fxml"));
            primaryStage.setTitle("University Management System");
            primaryStage.setScene(new Scene(root));
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    // ===================================================================
    // ==         DATABASE LOGIC (CRUD METHODS) FOR CONTROLLER        ==
    // ===================================================================

    // --- COURSE METHODS ---
    public static void insertCourse(Connection conn, String cid, String cname, String description, double fee) throws SQLException {
        String sql = "INSERT INTO Course (CID, Cname, C_description, C_fee) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cid);
            pstmt.setString(2, cname);
            pstmt.setString(3, description);
            pstmt.setDouble(4, fee);
            pstmt.executeUpdate();
        }
    }
    public static void updateCourse(Connection conn, String cid, String newCname, String newDescription, double newFee) throws SQLException {
        String sql = "UPDATE Course SET Cname = ?, C_description = ?, C_fee = ? WHERE CID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newCname);
            pstmt.setString(2, newDescription);
            pstmt.setDouble(3, newFee);
            pstmt.setString(4, cid);
            pstmt.executeUpdate();
        }
    }
    public static void deleteCourse(Connection conn, String cid) throws SQLException {
        String sql = "DELETE FROM Course WHERE CID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cid);
            pstmt.executeUpdate();
        }
    }

    // --- MODULE METHODS ---
    public static void insertModule(Connection conn, String mcode, String mname, String description, int credits) throws SQLException {
        String sql = "INSERT INTO Module (Mcode, Mname, M_description, NoOfCredits) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, mcode);
            pstmt.setString(2, mname);
            pstmt.setString(3, description);
            pstmt.setInt(4, credits);
            pstmt.executeUpdate();
        }
    }
    public static void updateModule(Connection conn, String mcode, String newMname, String newDescription, int newCredits) throws SQLException {
        String sql = "UPDATE Module SET Mname = ?, M_description = ?, NoOfCredits = ? WHERE Mcode = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newMname);
            pstmt.setString(2, newDescription);
            pstmt.setInt(3, newCredits);
            pstmt.setString(4, mcode);
            pstmt.executeUpdate();
        }
    }
    public static void deleteModule(Connection conn, String mcode) throws SQLException {
        String sql = "DELETE FROM Module WHERE Mcode = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, mcode);
            pstmt.executeUpdate();
        }
    }

    // --- STUDENT METHODS ---
    public static void insertStudent(Connection conn, String sid, String sname, String address, Date dob, String nic, String cid) throws SQLException {
        String sql = "INSERT INTO Student (SID, Sname, Address, dob, NIC, CID) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, sid);
            pstmt.setString(2, sname);
            pstmt.setString(3, address);
            pstmt.setDate(4, dob);
            pstmt.setString(5, nic);
            pstmt.setString(6, cid);
            pstmt.executeUpdate();
        }
    }
    public static void updateStudent(Connection conn, String sid, String newSname, String newAddress, Date newDob, String newNic, String newCid) throws SQLException {
        String sql = "UPDATE Student SET Sname = ?, Address = ?, dob = ?, NIC = ?, CID = ? WHERE SID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newSname);
            pstmt.setString(2, newAddress);
            pstmt.setDate(3, newDob);
            pstmt.setString(4, newNic);
            pstmt.setString(5, newCid);
            pstmt.setString(6, sid);
            pstmt.executeUpdate();
        }
    }
    public static void deleteStudent(Connection conn, String sid) throws SQLException {
        String sql = "DELETE FROM Student WHERE SID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, sid);
            pstmt.executeUpdate();
        }
    }

    // --- OFFERS METHODS ---
    public static void insertOffer(Connection conn, String cid, String mcode, String academicYear, int semester) throws SQLException {
        // Corrected SQL statement with standard spelling
        String sql = "INSERT INTO Offers (CID, Mcode, Academic_year, Semester) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cid);
            pstmt.setString(2, mcode);
            pstmt.setString(3, academicYear); // Changed from setDate
            pstmt.setInt(4, semester);
            pstmt.executeUpdate();
        }
    }
    public static void updateOffer(Connection conn, String cid, String mcode, String newAcademicYear, int newSemester) throws SQLException {
        // Corrected SQL statement with standard spelling
        String sql = "UPDATE Offers SET Academic_year = ?, Semester = ? WHERE CID = ? AND Mcode = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newAcademicYear); // Changed from setDate
            pstmt.setInt(2, newSemester);
            pstmt.setString(3, cid);
            pstmt.setString(4, mcode);
            pstmt.executeUpdate();
        }
    }
    public static void deleteOffer(Connection conn, String cid, String mcode) throws SQLException {
        String sql = "DELETE FROM Offers WHERE CID = ? AND Mcode = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cid);
            pstmt.setString(2, mcode);
            pstmt.executeUpdate();
        }
    }
}