import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;

public class MainController {

    // Course Fields
    @FXML private TextField courseIdField;
    @FXML private TextField courseNameField;
    @FXML private TextField courseDescField;
    @FXML private TextField courseFeeField;

    // Module Fields
    @FXML private TextField moduleCodeField;
    @FXML private TextField moduleNameField;
    @FXML private TextField moduleDescField;
    @FXML private TextField moduleCreditsField;

    // Student Fields
    @FXML private TextField studentIdField;
    @FXML private TextField studentNameField;
    @FXML private TextField studentAddressField;
    @FXML private DatePicker studentDobPicker;
    @FXML private TextField studentNicField;
    @FXML private TextField studentCourseIdField;

    // Offer Fields
    @FXML private TextField offerCourseIdField;
    @FXML private TextField offerModuleCodeField;
    @FXML private DatePicker offerYearPicker;
    @FXML private TextField offerSemesterField;

    // --- COURSE METHODS ---
    @FXML
    void addCourse() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String id = courseIdField.getText();
            String name = courseNameField.getText();
            String desc = courseDescField.getText();
            double fee = Double.parseDouble(courseFeeField.getText());
            MainApp.insertCourse(conn, id, name, desc, fee);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Course added successfully!");
        } catch (SQLException | NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add course: " + e.getMessage());
        }
    }

    @FXML
    void updateCourse() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String id = courseIdField.getText();
            String name = courseNameField.getText();
            String desc = courseDescField.getText();
            double fee = Double.parseDouble(courseFeeField.getText());
            MainApp.updateCourse(conn, id, name, desc, fee);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Course updated successfully!");
        } catch (SQLException | NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to update course: " + e.getMessage());
        }
    }

    @FXML
    void deleteCourse() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String id = courseIdField.getText();
            MainApp.deleteCourse(conn, id);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Course deleted successfully!");
        } catch (SQLException | NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete course: " + e.getMessage());
        }
    }

    // --- MODULE METHODS ---
    @FXML
    void addModule() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String code = moduleCodeField.getText();
            String name = moduleNameField.getText();
            String desc = moduleDescField.getText();
            int credits = Integer.parseInt(moduleCreditsField.getText());
            MainApp.insertModule(conn, code, name, desc, credits);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Module added successfully!");
        } catch (SQLException | NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add module: " + e.getMessage());
        }
    }

    @FXML
    void updateModule() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String code = moduleCodeField.getText();
            String name = moduleNameField.getText();
            String desc = moduleDescField.getText();
            int credits = Integer.parseInt(moduleCreditsField.getText());
            MainApp.updateModule(conn, code, name, desc, credits);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Module updated successfully!");
        } catch (SQLException | NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to update module: " + e.getMessage());
        }
    }

    @FXML
    void deleteModule() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String code = moduleCodeField.getText();
            MainApp.deleteModule(conn, code);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Module deleted successfully!");
        } catch (SQLException | NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete module: " + e.getMessage());
        }
    }

    // --- STUDENT METHODS ---
    @FXML
    void addStudent() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String id = studentIdField.getText();
            String name = studentNameField.getText();
            String address = studentAddressField.getText();
            Date dob = Date.valueOf(studentDobPicker.getValue());
            String nic = studentNicField.getText();
            String courseId = studentCourseIdField.getText();
            MainApp.insertStudent(conn, id, name, address, dob, nic, courseId);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Student added successfully!");
        } catch (SQLException | NumberFormatException | NullPointerException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add student: " + e.getMessage());
        }
    }

    @FXML
    void updateStudent() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String id = studentIdField.getText();
            String name = studentNameField.getText();
            String address = studentAddressField.getText();
            Date dob = Date.valueOf(studentDobPicker.getValue());
            String nic = studentNicField.getText();
            String courseId = studentCourseIdField.getText();
            MainApp.updateStudent(conn, id, name, address, dob, nic, courseId);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Student updated successfully!");
        } catch (SQLException | NumberFormatException | NullPointerException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to update student: " + e.getMessage());
        }
    }

    @FXML
    void deleteStudent() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String id = studentIdField.getText();
            MainApp.deleteStudent(conn, id);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Student deleted successfully!");
        } catch (SQLException | NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete student: " + e.getMessage());
        }
    }

    // --- OFFERS METHODS ---
    @FXML
    void addOffer() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String courseId = offerCourseIdField.getText();
            String moduleCode = offerModuleCodeField.getText();
            // **FIXED**: Get text directly from the editor to allow non-date strings
            String year = offerYearPicker.getEditor().getText();
            int semester = Integer.parseInt(offerSemesterField.getText());
            MainApp.insertOffer(conn, courseId, moduleCode, year, semester);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Offer added successfully!");
        } catch (SQLException | NumberFormatException | NullPointerException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add offer: " + e.getMessage());
        }
    }

    @FXML
    void updateOffer() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String courseId = offerCourseIdField.getText();
            String moduleCode = offerModuleCodeField.getText();
            // **FIXED**: Get text directly from the editor to allow non-date strings
            String year = offerYearPicker.getEditor().getText();
            int semester = Integer.parseInt(offerSemesterField.getText());
            MainApp.updateOffer(conn, courseId, moduleCode, year, semester);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Offer updated successfully!");
        } catch (SQLException | NumberFormatException | NullPointerException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to update offer: " + e.getMessage());
        }
    }

    @FXML
    void deleteOffer() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String courseId = offerCourseIdField.getText();
            String moduleCode = offerModuleCodeField.getText();
            MainApp.deleteOffer(conn, courseId, moduleCode);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Offer deleted successfully!");
        } catch (SQLException | NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete offer: " + e.getMessage());
        }
    }

    // Helper method to show alerts
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}