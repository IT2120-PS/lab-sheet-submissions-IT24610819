setwd("C:\\Users\\IT24610819\\Desktop\\IT24610819")

#Q1
branch_data <- read.csv("Exercise.txt")

#Q2
str(branch_data)

#Q3
boxplot(branch_data$Sales_X1,
        main="Boxplot of Sales_X1",
        ylab="Sales",
        col="lightblue",
        horizontal=TRUE)

#Q4
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#Q5
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}


